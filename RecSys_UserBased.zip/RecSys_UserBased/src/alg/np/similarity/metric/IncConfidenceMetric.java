/**
 * Compute the similarity between two items based on increase in confidence
 */ 

package alg.np.similarity.metric;

import java.util.Map;
import java.util.Set;

import util.reader.DatasetReader;

public class IncConfidenceMetric implements SimilarityMetric
{
	private static double RATING_THRESHOLD = 4.0; // the threshold rating for liked items 
	private DatasetReader reader; // dataset reader

	/**
	 * constructor - creates a new IncConfidenceMetric object
	 * @param reader - dataset reader
	 */
	public IncConfidenceMetric(final DatasetReader reader)
	{
		this.reader = reader;
	}

	/**
	 * computes the similarity between items
	 * @param X - the id of the first item 
	 * @param Y - the id of the second item
	 */
	public double getItemSimilarity(final Integer X, final Integer Y)
	{
		double sum_X=0;
		double sum_XY=0;
		double sum_notXY=0;
		double nX=0;
		double nY=0;
		double nXY=0;
		double n_XY=0;
		double x_rating;
		double y_rating;
		
		double supp_X=0;
		double supp_XY=0;
		double conf_XY=0;
		
		double supp_notX=0;
		double supp_notXY=0;
		double conf_notXY=0;
		
		double similarity=0;
		
	
		Map<Integer, profile.Profile> itemProfileMap = reader.getItemProfiles();
		profile.Profile x = itemProfileMap.get(X);
		profile.Profile y = itemProfileMap.get(Y);
		
		Set<Integer> rx_id=x.getIds();
		nX=x.getSize();
		for(Integer key:rx_id)
		{
			x_rating = x.getValue(key);
			if(x_rating>=RATING_THRESHOLD)
			{
				sum_X+=1;
			}
		}
				
		Set<Integer> r_id = x.getCommonIds(y);
		
		for(Integer key:r_id)
		{
			x_rating = x.getValue(key);
			y_rating = y.getValue(key);
			
			nXY+=1;
			if(y_rating>=RATING_THRESHOLD && x_rating>=RATING_THRESHOLD )
			{
				sum_XY+=1;
			}
			if(y_rating>=RATING_THRESHOLD && x_rating<RATING_THRESHOLD )
			{
				sum_notXY+=1;
			}
		}
		
		nY=y.getSize();
		n_XY=nX+nY-nXY;

		
		if  (nX ==0)
		{
			supp_X=0;
			supp_notX=0;
		}
		else
		{
			supp_X=sum_X/nX;
			supp_notX= (nX-sum_X)/nX;
		}
		
		if  (n_XY ==0)
		{
			supp_XY=0;
			supp_notXY=0;
		}
		else
		{
			supp_XY=sum_XY/n_XY;
			supp_notXY=(sum_notXY)/n_XY;
		}
		
		
		if  (supp_X == 0)
		{
			conf_XY=0;
		}
		else
		{
			conf_XY=supp_XY/supp_X;	
		}
		
		if  (supp_notX ==0)
		{
			conf_notXY=0;
		}
		else
		{
			conf_notXY=supp_notXY/supp_notX;
		}
		
		if (conf_notXY==0)
		{
			similarity= 0;
		}
		else
		{
			similarity= conf_XY/conf_notXY;
		}
		
		return similarity;
	}
}
