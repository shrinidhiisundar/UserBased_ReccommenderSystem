/**
 * Compute the similarity between two items based on the Cosine between item ratings
 */ 

package alg.np.similarity.metric;

import java.util.Map;
import java.util.Set;

import util.reader.DatasetReader;

public class RatingMetric implements SimilarityMetric
{
	private DatasetReader reader; // dataset reader

	/**
	 * constructor - creates a new RatingMetric object
	 * @param reader - dataset reader
	 */
	public RatingMetric(final DatasetReader reader)
	{
		this.reader = reader;
	}

	/**
	 * computes the similarity between items
	 * @param X - the id of the first item 
	 * @param Y - the id of the second item
	 */
	public double getItemSimilarity(final Integer X, final Integer Y)
	{
		double x_rating=0;
		double y_rating=0;
		double numerator=0;
		double x_denom=0;
		double y_denom=0;
		
		Map<Integer, profile.Profile> itemProfileMap = reader.getItemProfiles();
		profile.Profile x = itemProfileMap.get(X);
		profile.Profile y = itemProfileMap.get(Y);
		//computing common Ids
		Set<Integer> r_id = x.getCommonIds(y);
		for(Integer key:r_id)
		{
			x_rating = x.getValue(key);
			y_rating = y.getValue(key);
			numerator+=x_rating*y_rating;
		}
		
		/*Set<Integer> rx_id = x.getCommonIds(x);*/
		Set<Integer> rx_id=x.getIds();
		for(Integer key:rx_id)
		{
			x_rating = x.getValue(key);
			x_denom+=x.getValue(key)*x.getValue(key);
		}
		
		/*Set<Integer> ry_id = y.getCommonIds(y);*/
		Set<Integer> ry_id=y.getIds();
		for(Integer key:ry_id)
		{
			y_rating = y.getValue(key);
			y_denom+=y.getValue(key)*y.getValue(key);
		}
		
		return numerator/(Math.sqrt(x_denom) * Math.sqrt(y_denom));
	}
}
